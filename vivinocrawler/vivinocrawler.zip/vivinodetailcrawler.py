import requests
from bs4 import BeautifulSoup
import csv
import urllib3
import time
import random

# Suppress only the single InsecureRequestWarning from urllib3 needed for this scenario
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# List of wine URLs
wine_urls = [
    "https://www.vivino.com/krohn-colheita-port/w/1136061"
    # Add more wine URLs here
]

# Function to get the wine details from a Vivino page
def get_wine_details(url):
    try:
        response = requests.get(url, verify=False, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')

        # Initialize a dictionary to store the wine details
        wine_details = {}

        # Extracting Wine Name
        winery_tag = soup.find('a', class_='winery')
        vintage_tag = soup.find('span', class_='vintage')

        if winery_tag and vintage_tag:
            winery = winery_tag.text.strip()
            vintage = vintage_tag.text.strip()
            wine_details['Wine Name'] = f"{winery} {vintage}"
        else:
            wine_details['Wine Name'] = "N/A"

        # Extracting Country, Region, Winery, Wine Type, Grape
        breadcrumb_elements = soup.find('div', class_='breadCrumbs__breadCrumbs--2pkcX')
        if breadcrumb_elements:
            breadcrumb_elements = breadcrumb_elements.find_all('a', class_='anchor_anchor__m8Qi- breadCrumbs__link--1TY6b')
            if len(breadcrumb_elements) >= 5:
                wine_details['Country'] = breadcrumb_elements[0].text.strip()
                wine_details['Region'] = breadcrumb_elements[1].text.strip()
                wine_details['Winery'] = breadcrumb_elements[2].text.strip()
                wine_details['Wine Type'] = breadcrumb_elements[3].text.strip()
                wine_details['Grape'] = breadcrumb_elements[4].text.strip()
            else:
                wine_details.update({'Country': "N/A", 'Region': "N/A", 'Winery': "N/A", 'Wine Type': "N/A", 'Grape': "N/A"})
        else:
            wine_details.update({'Country': "N/A", 'Region': "N/A", 'Winery': "N/A", 'Wine Type': "N/A", 'Grape': "N/A"})

        # Extracting Wine Titles
        highlights = soup.find_all('div', class_='highlight')
        titles = []
        for highlight in highlights:
            titles.append(highlight.find_all('span')[0].text.strip())
        wine_details['Titles'] = titles

        # Extracting Facts about the wine
        facts = {}
        fact_rows = soup.find('table', class_='wineFacts__wineFacts--2Ih8B')
        if fact_rows:
            fact_rows = fact_rows.find_all('tr')
            for row in fact_rows:
                key_tag = row.find('span', class_='wineFacts__headerLabel--14doB')
                value_tag = row.find('td', class_='wineFacts__fact--3BAsi')
                if key_tag and value_tag:
                    facts[key_tag.text.strip()] = value_tag.text.strip()
        wine_details.update(facts)

        # Extracting Taste Profile
        taste_profile = {}
        taste_rows = soup.find('table', class_='tasteStructure__tasteStructure--3YUrG')
        if taste_rows:
            taste_rows = taste_rows.find_all('tr')
            for row in taste_rows:
                characteristic = row.find_all('div', class_='tasteStructure__property--CLNl_')
                progress_bar = row.find('span', class_='indicatorBar__progress--3aXLX')
                if characteristic and progress_bar:
                    taste_profile[f"{characteristic[0].text.strip()}-{characteristic[1].text.strip()}"] = progress_bar['style'].split(': ')[1]
        wine_details.update(taste_profile)

        # Extracting Food Pairing
        food_pairings = []
        food_items = soup.find_all('div', class_='foodPairing__foodImage--2OYHg')
        for item in food_items:
            food_pairings.append(item['aria-label'])
        wine_details['Food Pairing'] = food_pairings

        return wine_details
    except requests.exceptions.HTTPError as http_err:
        if http_err.response.status_code == 429:
            print(f"HTTP error 429: Too Many Requests for {url}")
            return None
        else:
            print(f"HTTP error: {http_err}")
            return None
    except requests.RequestException as e:
        print(f"HTTP error: {e}")
        return None
    except Exception as e:
        print(f"Error fetching details for {url}: {e}")
        return None

# Collecting all wine details
wine_data = []
retry_attempts = 5
for url in wine_urls:
    attempts = 0
    while attempts < retry_attempts:
        wine_details = get_wine_details(url)
        if wine_details:
            wine_data.append(wine_details)
            break
        else:
            attempts += 1
            sleep_time = random.uniform(30, 60)  # Random sleep time between 30 and 60 seconds
            print(f"Retrying in {sleep_time:.2f} seconds...")
            time.sleep(sleep_time)
    if attempts == retry_attempts:
        print(f"Failed to fetch data for {url} after {retry_attempts} attempts.")
    time.sleep(random.uniform(1, 5))  # Random delay between 1 and 5 seconds between requests

# Writing data to CSV
if wine_data:
    keys = wine_data[0].keys()
    with open('wine_data.csv', 'w', newline='', encoding='utf-8') as output_file:
        dict_writer = csv.DictWriter(output_file, fieldnames=keys)
        dict_writer.writeheader()
        dict_writer.writerows(wine_data)

    print("Data has been successfully written to wine_data.csv")
else:
    print("No data to write.")
